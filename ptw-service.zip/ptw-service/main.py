import sys
import logging
from logging import config
from multiprocessing import Queue
from multiprocessing.context import Process
from typing import List

import environ

from event.organisation_event_processor import OrganisationEventProcessor
from event.utils.config import KafkaConfig
from event.utils.ils_event_consumer import IlsEventConsumer
from utils.token import IlsApiTokenRefresher

env = environ.FileAwareEnv()

log_level = env('LOG_LEVEL', default="DEBUG")

log_config = {
    "version": 1,
    "root": {
        "handlers": ["console"],
        "level": log_level
    },
    "handlers": {
        "console": {
            "formatter": "std_out",
            "class": "logging.StreamHandler",
            "level": log_level,
            "stream": sys.stdout
        }
    },
    "formatters": {
        "std_out": {
            "format": '[%(asctime)s] "%(levelname)s" "%(module)s" "%(message)s"',
            "datefmt": "%d/%b/%Y %I:%M:%S"
        }
    },
}

config.dictConfig(log_config)

logger = logging.getLogger(__name__)


def start_application():
    logger.info("Starting application...")

    processes: List[Process] = []
    message_queue = Queue()

    consumer = IlsEventConsumer(message_queue)

    kafka_config = KafkaConfig()

    token_refresher = IlsApiTokenRefresher()

    logger.info(f'ils-api access: {token_refresher.get_token().is_valid()}')

    processes.append(
        OrganisationEventProcessor(message_queue, kafka_config=kafka_config, token_refresher=token_refresher))

    for process in processes:
        logger.debug(f"Starting process: '{process.name}'")
        process.start()

    consumer.start_consumer()

    for process in processes:
        logger.debug(f"Ending process: '{process.name}'")
        process.join()
        process.close()
        logger.info(f"Process {process.name} as fully stopped!")


if __name__ == '__main__':
    start_application()
