# What is this?

> 🛑 This package contains only generated code, **please do not modify it manually**.
 
### 👉 If necessary, follow the instructions inside the `vendor` folder.