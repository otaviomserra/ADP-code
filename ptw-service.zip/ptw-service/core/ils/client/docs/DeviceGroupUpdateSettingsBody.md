# DeviceGroupUpdateSettingsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**settings** | **dict(str, object)** | Settings to update of a Device Group (e.g &#x27;key&#x27;:&#x27;value&#x27;) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

