# IdentifierEnrichmentsDuplicatedOccurrence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enrichment_key** | **str** |  | [optional] 
**occurrences** | [**list[IdentifiersByEnrichmentValue]**](IdentifiersByEnrichmentValue.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

