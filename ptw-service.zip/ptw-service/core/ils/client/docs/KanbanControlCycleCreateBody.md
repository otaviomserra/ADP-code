# KanbanControlCycleCreateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number_of_cards** | **int** | Initial number of cards. | [optional] 
**name** | **str** | The Kanban Control Cycle&#x27;s name. | 
**external_id** | **str** | An External unique identifier to reference the Kanban Control Cycle. | [optional] 
**description** | **str** | The Kanban Control Cycle&#x27;s description. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

