# SetLightOperationBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**side** | **str** | The side of the Lanes. | [optional] 
**color** | **str** | Select the color you which to see. | 
**duration** | **int** | Select the duration (in seconds) on wish the light will be on. | [optional] 
**blink** | **bool** | Select if the light should blink or be solid during the execution of the command | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

