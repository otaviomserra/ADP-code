# SetImageOperationBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**device_ids** | **list[str]** | Target Device Ids. | 
**image_base64** | **str** | Image in base64 format. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

