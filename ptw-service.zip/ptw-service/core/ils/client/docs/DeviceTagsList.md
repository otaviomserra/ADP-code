# DeviceTagsList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **list[str]** | The tags assigned to the Device. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

